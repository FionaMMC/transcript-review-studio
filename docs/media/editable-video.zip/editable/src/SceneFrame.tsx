import type { ReactNode } from "react";
import {
  AbsoluteFill,
  Easing,
  Img,
  Interactive,
  interpolate,
  staticFile,
  useCurrentFrame,
} from "remotion";

export const SceneFrame = ({
  title,
  number,
  children,
}: {
  title: string;
  number: string;
  children: ReactNode;
}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        background: "#f4f6fa",
        color: "#152131",
        fontFamily: "Arial, Helvetica, sans-serif",
      }}
    >
      <Interactive.Div
        name="Brand"
        style={{
          position: "absolute",
          left: 96,
          top: 48,
          display: "flex",
          alignItems: "center",
          gap: 18,
          fontSize: 28,
          fontWeight: 700,
        }}
      >
        <Img src={staticFile("logo.svg")} style={{ width: 48, height: 48 }} />
        Transcript Review Studio
      </Interactive.Div>
      <Interactive.Div
        name="Chapter"
        style={{
          position: "absolute",
          right: 100,
          top: 63,
          color: "#50637a",
          fontSize: 26,
          letterSpacing: 2,
        }}
      >
        {number} / PRODUCT TOUR
      </Interactive.Div>
      <Interactive.Div
        name="Scene title"
        style={{
          position: "absolute",
          left: 96,
          top: 130,
          fontSize: 76,
          lineHeight: 1.07,
          fontWeight: 700,
          letterSpacing: -2.4,
          opacity: interpolate(frame, [0, 12], [0, 1], {
            extrapolateRight: "clamp",
          }),
          translate: interpolate(frame, [0, 16], ["0px 18px", "0px 0px"], {
            easing: Easing.bezier(0.16, 1, 0.3, 1),
            extrapolateRight: "clamp",
          }),
        }}
      >
        {title}
      </Interactive.Div>
      {children}
    </AbsoluteFill>
  );
};
