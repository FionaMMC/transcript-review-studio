import type { Caption } from "@remotion/captions";
import { useCurrentFrame, useVideoConfig } from "remotion";

export const Captions = ({ captions }: { captions: Caption[] }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const now = (frame / fps) * 1000;
  const caption = captions.find(
    (item, index) =>
      now >= item.startMs &&
      now <
        Math.min(captions[index + 1]?.startMs ?? Infinity, item.endMs + 220),
  );
  if (!caption) return null;
  return (
    <div
      style={{
        position: "absolute",
        bottom: 38,
        left: 132,
        right: 132,
        display: "flex",
        justifyContent: "center",
        pointerEvents: "none",
      }}
    >
      <div
        style={{
          maxWidth: 1580,
          background: "#172132",
          color: "white",
          padding: "19px 36px",
          borderRadius: 16,
          fontFamily: "Arial, Helvetica, sans-serif",
          fontSize: 36,
          lineHeight: 1.26,
          textAlign: "center",
          boxShadow: "0 8px 30px #11182712",
        }}
      >
        {caption.text}
      </div>
    </div>
  );
};
