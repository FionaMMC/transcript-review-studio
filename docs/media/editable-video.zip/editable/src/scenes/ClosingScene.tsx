import { Video } from "@remotion/media";
import { Interactive, staticFile } from "remotion";
import { SceneFrame } from "../SceneFrame";
export const ClosingScene = () => (
  <SceneFrame number="07" title="Try it with the sample project">
    <Interactive.Div
      name="Actual practice walkthrough"
      style={{
        position: "absolute",
        left: 110,
        top: 282,
        width: 1700,
        height: 671,
        borderRadius: 24,
        overflow: "hidden",
        boxShadow: "0 16px 44px #15213118",
      }}
    >
      <Video
        src={staticFile("clips/guide.mp4")}
        muted
        style={{ width: "100%", height: "100%" }}
        objectFit="contain"
      />
    </Interactive.Div>
  </SceneFrame>
);
