import { Interactive } from "remotion";
import { SceneFrame } from "../SceneFrame";
export const AuditScene = () => (
  <SceneFrame number="05" title="Show a colleague what changed">
    <Interactive.Div
      name="Actual exported change row"
      style={{
        position: "absolute",
        left: 100,
        right: 100,
        top: 284,
        border: "2px solid #dce3ed",
        borderRadius: 24,
        background: "white",
        padding: 48,
        height: 416,
      }}
    >
      <div style={{ fontSize: 26, color: "#63758c", marginBottom: 34 }}>
        FROM THE EXPORTED ENGLISH CHANGE LOG · SEGMENT 1
      </div>
      <div style={{ display: "flex", gap: 78 }}>
        <div style={{ width: 760 }}>
          <div style={{ fontSize: 30, color: "#63758c", marginBottom: 28 }}>
            Before · source VTT
          </div>
          <div style={{ fontSize: 48, lineHeight: 1.25 }}>
            If you say{" "}
            <span style={{ background: "#fff0dc", color: "#9a5100" }}>
              [practice-error]
            </span>
            <br />I just...
          </div>
        </div>
        <div style={{ width: 740 }}>
          <div style={{ fontSize: 30, color: "#63758c", marginBottom: 28 }}>
            Current · saved draft
          </div>
          <div style={{ fontSize: 48, lineHeight: 1.25 }}>
            If you say{" "}
            <span style={{ background: "#e4f1ff", color: "#0964d8" }}>and</span>{" "}
            I just...
          </div>
          <div style={{ fontSize: 28, color: "#9a5100", marginTop: 29 }}>
            Review status: pending
          </div>
        </div>
      </div>
    </Interactive.Div>
    <Interactive.Div
      name="Sharing the review record"
      style={{
        position: "absolute",
        left: 110,
        top: 783,
        fontSize: 44,
        lineHeight: 1.5,
        color: "#50637a",
      }}
    >
      Export the change log alongside your transcript.
    </Interactive.Div>
    <Interactive.Div
      name="Seeded baseline disclosure"
      style={{
        position: "absolute",
        left: 110,
        top: 706,
        fontSize: 24,
        color: "#63758c",
      }}
    >
      A seeded practice error, not a claim of machine transcription accuracy.
    </Interactive.Div>
  </SceneFrame>
);
