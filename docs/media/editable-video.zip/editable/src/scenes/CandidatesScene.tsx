import { Video } from "@remotion/media";
import { Interactive, staticFile } from "remotion";
import { SceneFrame } from "../SceneFrame";
export const CandidatesScene = () => (
  <SceneFrame number="01" title="Find the passages worth a closer listen">
    <Interactive.Div
      name="Candidate comparison label"
      style={{
        position: "absolute",
        left: 110,
        top: 304,
        fontSize: 44,
        fontWeight: 600,
      }}
    >
      Compare the candidate transcripts.
    </Interactive.Div>
    <Interactive.Div
      name="Actual candidate wording"
      style={{
        position: "absolute",
        left: 100,
        top: 394,
        width: 1090,
        height: 286,
        borderRadius: 22,
        overflow: "hidden",
        background: "#fff",
        boxShadow: "0 14px 42px #15213116",
      }}
    >
      <Video
        src={staticFile("clips/compare.mp4")}
        muted
        style={{ width: "100%", height: "100%" }}
        objectFit="contain"
      />
    </Interactive.Div>
    <Interactive.Div
      name="Review priority explanation"
      style={{
        position: "absolute",
        left: 112,
        top: 735,
        width: 1030,
        fontSize: 39,
        lineHeight: 1.35,
        color: "#50637a",
      }}
    >
      Use differences and model confidence
      <br />
      to choose where to listen next.
    </Interactive.Div>
    <Interactive.Div
      name="Actual attention queue"
      style={{
        position: "absolute",
        left: 1290,
        top: 272,
        width: 510,
        height: 666,
        borderRadius: 20,
        overflow: "hidden",
        boxShadow: "0 14px 42px #15213116",
      }}
    >
      <Video
        src={staticFile("clips/queue.mp4")}
        muted
        style={{ width: "100%", height: "100%" }}
        objectFit="contain"
      />
    </Interactive.Div>
    <Interactive.Div
      name="Candidate qualification"
      style={{
        position: "absolute",
        left: 112,
        top: 880,
        width: 1070,
        fontSize: 24,
        lineHeight: 1.35,
        color: "#63758c",
      }}
    >
      Two local passes of the same model. Practice text includes a seeded error.
      <br />
      Model scores guide review; they do not certify correctness.
    </Interactive.Div>
  </SceneFrame>
);
