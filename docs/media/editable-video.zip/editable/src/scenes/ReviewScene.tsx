import { Video } from "@remotion/media";
import { Interactive, Sequence, staticFile, useCurrentFrame } from "remotion";
import { SceneFrame } from "../SceneFrame";
export const ReviewScene = () => {
  const frame = useCurrentFrame();
  return (
    <SceneFrame number="03" title="Make the correction as you listen">
      <Interactive.Div
        name="Playback and editing demonstration"
        style={{
          position: "absolute",
          left: 100,
          top: 250,
          width: 1720,
          height: 646,
          borderRadius: 24,
          overflow: "hidden",
          boxShadow: "0 16px 44px #15213116",
          background: "#fff",
        }}
      >
        <Sequence durationInFrames={98}>
          <Video
            src={staticFile("clips/playback.mp4")}
            muted
            style={{ width: "100%", height: "100%" }}
            objectFit="contain"
          />
        </Sequence>
        <Sequence from={98} durationInFrames={60}>
          <Video
            src={staticFile("clips/compare.mp4")}
            muted
            style={{ width: "100%", height: "100%" }}
            objectFit="contain"
          />
        </Sequence>
        <Sequence from={158}>
          <Video
            src={staticFile("clips/after-edit.mp4")}
            muted
            style={{ width: "100%", height: "100%" }}
            objectFit="contain"
          />
        </Sequence>
      </Interactive.Div>
      <Interactive.Div
        name="Demonstration status"
        style={{
          position: "absolute",
          right: 124,
          top: 258,
          fontSize: 26,
          color: "#0964d8",
          background: "#edf4ff",
          padding: "9px 16px",
          borderRadius: 10,
        }}
      >
        {frame < 158
          ? "Listen, compare, then edit"
          : "Demonstration saved as pending — not verified"}
      </Interactive.Div>
    </SceneFrame>
  );
};
