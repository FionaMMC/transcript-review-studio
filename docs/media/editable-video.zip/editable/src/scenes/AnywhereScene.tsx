import { Video } from "@remotion/media";
import { Interactive, staticFile } from "remotion";
import { SceneFrame } from "../SceneFrame";
export const AnywhereScene = () => (
  <SceneFrame number="02" title="Check any part of the conversation">
    <Interactive.Div
      name="Actual unflagged passage playback"
      style={{
        position: "absolute",
        left: 100,
        top: 271,
        width: 1180,
        height: 686,
        borderRadius: 22,
        overflow: "hidden",
        boxShadow: "0 14px 42px #15213116",
      }}
    >
      <Video
        src={staticFile("clips/anywhere.mp4")}
        muted
        style={{ width: "100%", height: "100%" }}
        objectFit="contain"
      />
    </Interactive.Div>
    <Interactive.Div
      name="Full review access"
      style={{
        position: "absolute",
        left: 1340,
        top: 404,
        width: 460,
        fontSize: 57,
        lineHeight: 1.2,
        fontWeight: 600,
        color: "#0964d8",
      }}
    >
      All segments.
      <br />
      Not just the
      <br />
      flagged ones.
    </Interactive.Div>
    <Interactive.Div
      name="Unflagged example"
      style={{
        position: "absolute",
        left: 1342,
        top: 674,
        width: 447,
        fontSize: 29,
        lineHeight: 1.45,
        color: "#63758c",
      }}
    >
      An unflagged sample passage,
      <br />
      opened and replayed in the app.
    </Interactive.Div>
  </SceneFrame>
);
