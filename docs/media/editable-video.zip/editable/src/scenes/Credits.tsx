import { AbsoluteFill, Interactive } from "remotion";
export const Credits = () => (
  <AbsoluteFill
    style={{
      background: "#172132",
      fontFamily: "Arial, Helvetica, sans-serif",
      color: "#f4f6fa",
      padding: "112px 132px",
    }}
  >
    <Interactive.Div
      name="Credit heading"
      style={{ fontSize: 70, fontWeight: 700, marginBottom: 58 }}
    >
      Transcript Review Studio
    </Interactive.Div>
    <Interactive.Div
      name="Voice attribution"
      style={{ fontSize: 45, lineHeight: 1.4, fontWeight: 700 }}
    >
      AI narration · Chris via elevenlabs.io
    </Interactive.Div>
    <Interactive.Div
      name="Noncommercial voice notice"
      style={{ fontSize: 32, lineHeight: 1.5, marginTop: 14, color: "#bcc8da" }}
    >
      Noncommercial edition · generated on ElevenLabs Free
    </Interactive.Div>
    <Interactive.Div
      name="Footage credit"
      style={{ fontSize: 34, lineHeight: 1.5, maxWidth: 1610, marginTop: 68 }}
    >
      Public sample: “Preliminary discussions regarding Lua bot framework”
      <br />
      Jim Carter · Wikimedia Commons · CC BY-SA 4.0
      <br />
      Cropped on-screen excerpts; original audio omitted.
    </Interactive.Div>
    <Interactive.Div
      name="Release information"
      style={{ fontSize: 30, lineHeight: 1.5, marginTop: 65, color: "#bcc8da" }}
    >
      Release candidate · see installation requirements
      <br />
      Full source credits and usage notes accompany this video.
    </Interactive.Div>
  </AbsoluteFill>
);
