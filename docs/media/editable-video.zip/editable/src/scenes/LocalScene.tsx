import { Interactive } from "remotion";
import { SceneFrame } from "../SceneFrame";
export const LocalScene = () => (
  <SceneFrame number="06" title="Your research stays on your computer">
    <Interactive.Div
      name="Local workflow"
      style={{
        position: "absolute",
        left: 110,
        top: 324,
        fontSize: 83,
        lineHeight: 1.15,
        fontWeight: 650,
        letterSpacing: -2,
        color: "#0964d8",
      }}
    >
      Local speech recognition.
      <br />
      Local transcript review.
    </Interactive.Div>
    <Interactive.Div
      name="Privacy scope"
      style={{
        position: "absolute",
        left: 118,
        top: 589,
        width: 1610,
        fontSize: 46,
        lineHeight: 1.45,
      }}
    >
      The app does not upload your recordings
      <br />
      or transcripts to cloud services.
    </Interactive.Div>
    <Interactive.Div
      name="Model setup note"
      style={{
        position: "absolute",
        left: 120,
        top: 829,
        fontSize: 28,
        color: "#63758c",
      }}
    >
      Initial setup may download the speech model. Your research content is
      processed locally.
    </Interactive.Div>
  </SceneFrame>
);
