import { Video } from "@remotion/media";
import { Interactive, staticFile } from "remotion";
import { SceneFrame } from "../SceneFrame";
export const FormatsScene = () => (
  <SceneFrame
    number="04"
    title="Take your transcript into qualitative analysis"
  >
    <Interactive.Div
      name="Actual export screen"
      style={{
        position: "absolute",
        left: 98,
        top: 279,
        width: 1040,
        height: 600,
        borderRadius: 24,
        overflow: "hidden",
        boxShadow: "0 16px 44px #15213116",
      }}
    >
      <Video
        src={staticFile("clips/exports.mp4")}
        muted
        style={{ width: "100%", height: "100%" }}
        objectFit="contain"
      />
    </Interactive.Div>
    <Interactive.Div
      name="Readable documents"
      style={{
        position: "absolute",
        left: 1200,
        top: 286,
        fontSize: 49,
        fontWeight: 700,
        color: "#0964d8",
      }}
    >
      Word · DOCX
    </Interactive.Div>
    <Interactive.Div
      name="Document explanation"
      style={{
        position: "absolute",
        left: 1200,
        top: 348,
        fontSize: 31,
        lineHeight: 1.35,
        width: 600,
        color: "#50637a",
      }}
    >
      Speaker-turn transcript
      <br />
      NVivo-style transcript table
    </Interactive.Div>
    <Interactive.Div
      name="Structured formats"
      style={{
        position: "absolute",
        left: 1200,
        top: 478,
        fontSize: 49,
        fontWeight: 700,
        color: "#0964d8",
      }}
    >
      Excel · CSV · JSON
    </Interactive.Div>
    <Interactive.Div
      name="Structured explanation"
      style={{
        position: "absolute",
        left: 1200,
        top: 540,
        fontSize: 31,
        lineHeight: 1.35,
        width: 600,
        color: "#50637a",
      }}
    >
      Turns, segments, working text,
      <br />
      and review status
    </Interactive.Div>
    <Interactive.Div
      name="Timed formats"
      style={{
        position: "absolute",
        left: 1200,
        top: 670,
        fontSize: 49,
        fontWeight: 700,
        color: "#0964d8",
      }}
    >
      VTT · SRT · TXT
    </Interactive.Div>
    <Interactive.Div
      name="Timed explanation"
      style={{
        position: "absolute",
        left: 1200,
        top: 732,
        fontSize: 31,
        lineHeight: 1.35,
        width: 600,
        color: "#50637a",
      }}
    >
      Timed captions
      <br />
      and a portable text copy
    </Interactive.Div>
    <Interactive.Div
      name="Compatibility qualification"
      style={{
        position: "absolute",
        left: 112,
        top: 885,
        fontSize: 25,
        color: "#63758c",
      }}
    >
      Check import compatibility with your qualitative-analysis software
      version.
    </Interactive.Div>
  </SceneFrame>
);
