import {
  AbsoluteFill,
  Easing,
  Img,
  Interactive,
  interpolate,
  staticFile,
  useCurrentFrame,
} from "remotion";
import { Video } from "@remotion/media";

export const Intro = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        background: "#eef3fc",
        fontFamily: "Arial, Helvetica, sans-serif",
        color: "#152131",
      }}
    >
      <Interactive.Div
        name="Product name"
        style={{
          position: "absolute",
          left: 104,
          top: 114,
          display: "flex",
          gap: 24,
          alignItems: "center",
          fontSize: 34,
          fontWeight: 700,
        }}
      >
        <Img src={staticFile("logo.svg")} style={{ width: 78, height: 78 }} />
        Transcript Review Studio
      </Interactive.Div>
      <Interactive.Div
        name="Qualitative research purpose"
        style={{
          position: "absolute",
          left: 104,
          top: 302,
          width: 850,
          fontSize: 87,
          fontWeight: 700,
          lineHeight: 1.1,
          letterSpacing: -3,
          opacity: interpolate(frame, [0, 16], [0, 1], {
            extrapolateRight: "clamp",
          }),
        }}
      >
        Get your interviews
        <br />
        ready for <span style={{ color: "#0964d8" }}>analysis.</span>
      </Interactive.Div>
      <Interactive.Div
        name="Opening explanation"
        style={{
          position: "absolute",
          left: 108,
          top: 630,
          fontSize: 39,
          lineHeight: 1.4,
          width: 760,
          color: "#50637a",
        }}
      >
        Check what was said
        <br />
        before you code or quote it.
      </Interactive.Div>
      <Interactive.Div
        name="Actual app preview"
        style={{
          position: "absolute",
          left: 950,
          top: 286,
          width: 870,
          height: 440,
          borderRadius: 26,
          overflow: "hidden",
          boxShadow: "0 24px 65px #183a6826",
          border: "2px solid #ffffff",
          scale: interpolate(frame, [0, 45], [0.96, 1], {
            output: "perceptual-scale",
            easing: Easing.bezier(0.16, 1, 0.3, 1),
            extrapolateRight: "clamp",
          }),
        }}
      >
        <Video
          src={staticFile("clips/playback.mp4")}
          muted
          style={{ width: "100%", height: "100%" }}
          objectFit="contain"
        />
      </Interactive.Div>
      <Interactive.Div
        name="Capture disclosure"
        style={{
          position: "absolute",
          left: 968,
          top: 754,
          fontSize: 26,
          color: "#50637a",
        }}
      >
        Actual app capture · public demonstration data
      </Interactive.Div>
    </AbsoluteFill>
  );
};
