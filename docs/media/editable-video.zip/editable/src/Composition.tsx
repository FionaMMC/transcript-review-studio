import type { ReactNode } from "react";
import { Audio } from "@remotion/media";
import { TransitionSeries } from "@remotion/transitions";
import { AbsoluteFill, Composition, Sequence, staticFile } from "remotion";
import { Captions } from "./Captions";
import timeline from "./timeline.json";
import { Intro } from "./scenes/Intro";
import { CandidatesScene } from "./scenes/CandidatesScene";
import { AnywhereScene } from "./scenes/AnywhereScene";
import { ReviewScene } from "./scenes/ReviewScene";
import { FormatsScene } from "./scenes/FormatsScene";
import { AuditScene } from "./scenes/AuditScene";
import { LocalScene } from "./scenes/LocalScene";
import { ClosingScene } from "./scenes/ClosingScene";
import { Credits } from "./scenes/Credits";

const Narrated = ({ id, children }: { id: string; children: ReactNode }) => {
  const scene = timeline.scenes.find((item) => item.id === id)!;
  return (
    <AbsoluteFill>
      {children}
      <Sequence from={12}>
        <Audio src={staticFile(`voiceover/${id}.mp3`)} />
      </Sequence>
      <Captions captions={scene.captions} />
    </AbsoluteFill>
  );
};

export const ProductTour = () => (
  <TransitionSeries name="English product tour">
    <TransitionSeries.Sequence
      name="Qualitative research introduction"
      durationInFrames={278}
    >
      <Narrated id="intro">
        <Intro />
      </Narrated>
    </TransitionSeries.Sequence>
    <TransitionSeries.Sequence
      name="Candidates and confidence"
      durationInFrames={435}
    >
      <Narrated id="candidates">
        <CandidatesScene />
      </Narrated>
    </TransitionSeries.Sequence>
    <TransitionSeries.Sequence
      name="Unflagged passage review"
      durationInFrames={143}
    >
      <Narrated id="anywhere">
        <AnywhereScene />
      </Narrated>
    </TransitionSeries.Sequence>
    <TransitionSeries.Sequence name="Human review" durationInFrames={321}>
      <Narrated id="review">
        <ReviewScene />
      </Narrated>
    </TransitionSeries.Sequence>
    <TransitionSeries.Sequence
      name="Qualitative analysis exports"
      durationInFrames={225}
    >
      <Narrated id="formats">
        <FormatsScene />
      </Narrated>
    </TransitionSeries.Sequence>
    <TransitionSeries.Sequence name="Correction record" durationInFrames={146}>
      <Narrated id="audit">
        <AuditScene />
      </Narrated>
    </TransitionSeries.Sequence>
    <TransitionSeries.Sequence name="Local privacy" durationInFrames={196}>
      <Narrated id="privacy">
        <LocalScene />
      </Narrated>
    </TransitionSeries.Sequence>
    <TransitionSeries.Sequence name="Sample walkthrough" durationInFrames={141}>
      <Narrated id="outro">
        <ClosingScene />
      </Narrated>
    </TransitionSeries.Sequence>
    <TransitionSeries.Sequence
      name="Attribution and usage"
      durationInFrames={210}
    >
      <Credits />
    </TransitionSeries.Sequence>
  </TransitionSeries>
);

export const MyComposition = () => (
  <Composition
    id="TranscriptReviewStudio"
    component={ProductTour}
    width={1920}
    height={1080}
    fps={30}
    durationInFrames={2095}
    calculateMetadata={() => ({
      durationInFrames: timeline.durationInFrames,
      defaultOutName: "TranscriptReviewStudio_Promo_EN_elevenlabs.io",
    })}
  />
);
