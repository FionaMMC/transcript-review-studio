# Transcript Review Studio — editable English video

The final approved script focuses on local candidate transcripts, confidence-assisted prioritisation, human review anywhere in the recording, and exports for qualitative analysis.

## Preview and render

Requires Node.js, npm and FFmpeg on your PATH. From this folder:

```sh
npm ci
npm run lint
npm run verify
npm run dev
```

Select `TranscriptReviewStudio` in Remotion Studio. To render:

```sh
npm run render
npm run finish
```

The finished file is `out/transcript-review-studio-elevenlabs-1080p.mp4`. `finish` normalises voice loudness and prepares the MP4 for streaming. It refuses to overwrite a previous finished cut. No ElevenLabs key is needed to re-render the supplied audio; rendering does not generate more speech or consume TTS credits.

Dependency and rendering-browser downloads may occur on first use. Remotion Studio is a development server and can expose a network URL; do not add confidential material, and stop the server with Control-C when finished.

## Editing

- `src/scenes/` contains one component per chapter, with named editable elements.
- `src/Composition.tsx` contains the explicit scene durations and a 12-frame narration lead-in.
- `src/timeline.json` contains the script, measured voice durations and aligned captions.
- `public/clips/` contains cropped recordings of the real public practice workspace. Some shots hold the last frame; this is an edited demonstration, not a continuous processing-speed benchmark.
- `public/voiceover/` contains the final eight voice segments and non-secret provenance.
- `source/narration.json` and `source/alignment/` preserve the approved wording and source character timing.
- `public/export-evidence.json` records the actual demo export inventory and before/after example.

To replace spoken wording, supply new audio, update the matching caption timings and voice duration in `src/timeline.json`, and update the corresponding literal durations in `src/Composition.tsx`. Then run `npm run verify` and inspect the cut. Caption times are scene-relative milliseconds including a 400 ms lead-in. Changing only the visible subtitle does not change the voice.

## Production and rights

Built with the official [remotion-best-practices skill](https://github.com/remotion-dev/skills), revision `11986e44eeb672b083354e68967f2b194df73b7c`, version 4.0.522. It guided separate editable scenes, frame-based timing, aligned captions and local rendering. `verification-before-completion` guided the fresh media, narration and privacy checks.

Read `../PUBLISHING.md` before sharing. Original composition code is MIT-licensed (see `LICENSE`). The generated narration is noncommercial-only under the confirmed ElevenLabs Free scope; Wikimedia material retains its own CC BY-SA terms. This is not a blanket MIT-licensed media pack. Remotion itself has [licensing requirements](https://github.com/remotion-dev/remotion/blob/main/LICENSE.md), including a company licence for some organisations.

Raw screen frames, research data, credentials, Git history and installed dependencies are excluded from this handoff.
