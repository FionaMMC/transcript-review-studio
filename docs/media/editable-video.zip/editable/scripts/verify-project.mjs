import assert from 'node:assert/strict';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';

const timeline=JSON.parse(fs.readFileSync('src/timeline.json','utf8'));
const composition=fs.readFileSync('src/Composition.tsx','utf8');
const sequences=[...composition.matchAll(/<TransitionSeries\.Sequence[\s\S]*?durationInFrames=\{(\d+)\}/g)].map(match=>Number(match[1]));
assert.deepEqual(sequences,[...timeline.scenes.map(scene=>scene.durationInFrames),timeline.creditFrames]);
assert.equal(sequences.reduce((sum,frames)=>sum+frames,0),timeline.durationInFrames);
assert.equal(timeline.fps,30);
const subtitles=[];
const stamp=ms=>new Date(Math.round(ms)).toISOString().slice(11,23).replace('.',',');
let offset=0;
for(const scene of timeline.scenes){
  const duration=Number(JSON.parse(execFileSync('ffprobe',['-v','error','-show_entries','format=duration','-of','json',`public/voiceover/${scene.id}.mp3`],{encoding:'utf8'})).format.duration);
  assert.ok(Math.abs(duration-scene.voiceDuration)<0.03,`Changed voice duration: ${scene.id}`);
  assert.ok((duration+0.4)*30<=scene.durationInFrames,`Voice would be truncated: ${scene.id}`);
  let previousEnd=0;
  scene.captions.forEach((caption,index)=>{
    assert.ok(caption.text.trim());
    assert.ok(caption.startMs>=previousEnd && caption.endMs>caption.startMs,`Invalid caption timing: ${scene.id}`);
    const end=Math.min(scene.captions[index+1]?.startMs??Infinity,caption.endMs+220,scene.durationInFrames/30*1000);
    subtitles.push(`${subtitles.length+1}\n${stamp(offset+caption.startMs)} --> ${stamp(offset+end)}\n${caption.text}\n`);
    previousEnd=caption.endMs;
  });
  const norm=text=>text.replace(/\s+/g,' ').trim();
  assert.equal(norm(scene.captions.map(caption=>caption.text).join(' ')),norm(scene.text),`Caption/script mismatch: ${scene.id}`);
  offset+=scene.durationInFrames/30*1000;
}
for(const file of fs.readdirSync('public/clips')){
  const streams=JSON.parse(execFileSync('ffprobe',['-v','error','-show_entries','stream=codec_type','-of','json',`public/clips/${file}`],{encoding:'utf8'})).streams;
  assert.ok(streams.length>0 && streams.every(stream=>stream.codec_type==='video'),`Capture contains unexpected audio: ${file}`);
}
fs.mkdirSync('out',{recursive:true});
fs.writeFileSync('out/english-captions.srt',subtitles.join('\n'));
fs.writeFileSync('out/english-script.txt',timeline.scenes.map(scene=>scene.text).join('\n\n')+'\n');
console.log(`Verified ${timeline.scenes.length} narration scenes, ${subtitles.length} caption pages, ${timeline.durationInFrames} frames. Capture clips contain no audio.`);
