import fs from 'node:fs';
import {spawnSync} from 'node:child_process';

const input='out/promo-render.mp4';
const output='out/transcript-review-studio-elevenlabs-1080p.mp4';
if(!fs.existsSync(input))throw Error('Run npm run render first.');
if(fs.existsSync(output))throw Error('A finished MP4 already exists. Rename it to preserve that version before finishing a new cut.');
const measuredRun=spawnSync('ffmpeg',['-hide_banner','-i',input,'-vn','-af','loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json','-f','null','-'],{encoding:'utf8'});
if(measuredRun.status!==0)throw Error(measuredRun.stderr || 'Loudness measurement failed.');
const match=measuredRun.stderr.match(/\{\s*"input_i"[\s\S]*?\}/);
if(!match)throw Error('Could not parse measured loudness.');
const measured=JSON.parse(match[0]);
for(const field of ['input_i','input_tp','input_lra','input_thresh','target_offset'])if(!Number.isFinite(Number(measured[field])))throw Error('Missing or invalid narration.');
const filter=`loudnorm=I=-16:TP=-1.5:LRA=7:measured_I=${measured.input_i}:measured_TP=${measured.input_tp}:measured_LRA=${measured.input_lra}:measured_thresh=${measured.input_thresh}:offset=${measured.target_offset}:linear=false`;
const result=spawnSync('ffmpeg',['-hide_banner','-loglevel','warning','-i',input,'-map','0:v:0','-map','0:a:0','-c:v','copy','-af',filter,'-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart','-metadata','title=Transcript Review Studio | Product tour | elevenlabs.io','-metadata','comment=AI narration: Chris via ElevenLabs Free. Noncommercial edition. See PUBLISHING.md for source credits and usage notes.',output],{stdio:'inherit'});
if(result.status!==0)throw Error('Finishing failed.');
fs.writeFileSync('out/loudness-source.json',JSON.stringify(measured,null,2));
console.log(output);
