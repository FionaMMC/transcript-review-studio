# Video QA — 9 September 2026

## Delivered cut

- Container duration: **69.900 seconds**; picture: **2,095 frames / 69.833 seconds**.
- Video: **1920 × 1080, 30 fps, H.264**.
- Audio: **48 kHz stereo AAC**; generated English narration only, no music or original sample audio.
- Final MP4 size: **6,111,497 bytes**.
- Measured finished audio: **−16.01 LUFS integrated**, **−1.39 dBTP true peak**, **3.10 LU loudness range**. Two-pass normalisation targeted −16 LUFS / −1.5 dBTP; the reported peak is the measurement after AAC encoding.
- Captions: **22 pages**, matching the eight approved script passages. Burned into the MP4 and supplied separately as SRT.

## Checks performed

1. **Source and claims:** reviewed the local implementation of candidate generation, confidence/disagreement prioritisation, review states, local processing and exports. The film identifies same-model passes and the deliberately seeded practice correction. Its saved example remains pending, not verified.
2. **Actual public demo:** captured candidate comparison, low-recognition-score filtering, playback of an unflagged passage, editing, exports and the practice walkthrough in the real app. This is a cropped, edited tour with held frames, not a continuous screen recording or a performance benchmark.
3. **Export evidence:** generated ten individual public-demo export formats and a 21-file draft bundle; all 20 listed payload checksums matched. The Word/NVivo-style documents, workbook and audit structure were checked. Evidence is retained in `editable/public/export-evidence.json`; private research exports are not included.
4. **Narration:** all eight final ElevenLabs scenes were re-transcribed locally using cached `mlx-community/whisper-large-v3-turbo`, with offline mode and telemetry disabled. The recovered words match the approved script, ignoring punctuation and hyphenation. No interview audio was sent to ElevenLabs. A compact comparison is in `editable/source/voice-check.json`.
5. **Timing:** `npm run verify` passed for all eight narration scenes, 22 ordered caption pages and 2,095 frames. Audio fits its scene; caption text matches the script; all seven delivered screen-capture clips are video-only.
6. **Code and preview:** `npm run lint` (ESLint and TypeScript) passed. The Remotion preview reported no runtime error and the expected composition dimensions and duration.
7. **Visual inspection:** inspected representative renders of all nine scenes, including credits; checked final encoded frames for the candidate, guide and credit scenes. No headline or caption clipping was visible in the inspected frames.
8. **Finished media:** FFmpeg decoded the entire final MP4 with `-xerror` and exited successfully. FFprobe confirmed the stream properties above. Finished-file loudness was measured after normalisation and AAC encoding.
9. **Privacy and state:** captures used public practice data only. The existing private database hash still matched the pre-task baseline. The original public practice workspace was restored with its existing 1/160 reviewed progress. No Git commit, push or publication was performed.
10. **Handoff:** files were selected from an explicit public-only allowlist. Raw full-screen captures, private data, credentials, databases, Git history, dependencies and unused capture-preparation scripts are excluded. A local text/file scan and the generated integrity manifest are checked before delivery.

## Limitations and final human check

Local STT rechecking is an automated wording check, **not a claim of human listening or a guarantee of pronunciation, tone or naturalness**. Please watch once with sound before posting to approve the delivery and pace. Representative frame inspection is not a frame-by-frame human review.

This QA applies to the promotional cut, not a complete fresh security audit or release certification of the app. Native NVivo import, every analysis package, every operating system and all possible research workflows were not tested in this video task. See `PUBLISHING.md` for supported-platform wording and media rights.
