# Transcript Review Studio — English promotional video

Start with `transcript-review-studio-elevenlabs-1080p.mp4`.

This approximately 70-second, 1920 × 1080 product tour uses the approved English script, Chris AI narration from ElevenLabs, and recordings of the real app's public practice workspace. There is no background music or interview audio.

## Files

- `transcript-review-studio-elevenlabs-1080p.mp4` — finished H.264/AAC video with English captions burned in.
- `english-captions.srt` — matching editable subtitle file.
- `english-script.txt` — final spoken script.
- `cover.png` — full-resolution frame for a preview image.
- `PUBLISHING.md` — suggested English title/description, required credits, usage limits and accurate product claims.
- `QA.md` — checks performed and remaining review limitations.
- `editable/` — modular Remotion project, cropped public demo clips, approved narration and caption alignment; see its README to re-render.
- `checksums.sha256` — integrity checks for the delivered files.

The video covers candidate transcripts and confidence-assisted prioritisation, human review anywhere in a recording, correction and speaker editing, qualitative-analysis exports, change history, local processing, and the sample walkthrough.

**Sharing scope:** noncommercial with required ElevenLabs title attribution and Wikimedia source credits. Read `PUBLISHING.md` before publishing. This media pack is not covered by a blanket open-source software licence.

No private interview recordings, research transcripts, application database, credentials, Git history, raw full-screen captures or installed dependencies are included. Nothing was uploaded to GitHub as part of this handoff.

The editable video was made using the official `remotion-best-practices` skill for reusable scenes, timing and captions, with `verification-before-completion` for the final checks. Future narration changes can be made scene by scene without recreating the whole video.
