# Publishing the English product tour

## Suggested publication title

**Transcript Review Studio — Local transcript review for qualitative research | elevenlabs.io**

Keep `elevenlabs.io` in the publication title. The end card and description alone do not satisfy the current ElevenLabs Free title-attribution requirement.

## Suggested description

Get your interviews ready for qualitative analysis with Transcript Review Studio.

Generate candidate transcripts using local speech recognition, use wording differences and model confidence to focus your review, and check any passage yourself. Watch the recording, replay a sentence, compare versions, and edit as you listen.

Export a Word transcript, an NVivo-style table, a spreadsheet, or timed subtitles, with a before-and-after record of your corrections. The app processes recordings and transcripts locally; it does not send them to cloud transcription services.

Start with the included public sample and step-by-step walkthrough. See the project README for installation requirements and current platform support.

This is an edited demonstration of a release candidate, not a transcription accuracy or processing-speed benchmark. AI flags help prioritise review; they do not replace a researcher's judgement. The app prepares transcripts for qualitative analysis; it does not automatically code the data or generate research findings.

AI narration: Chris via elevenlabs.io. Generated on ElevenLabs Free for noncommercial use.

Public sample footage: “Preliminary discussions regarding Lua bot framework,” Jim Carter, 15 October 2016, Wikimedia Commons. Source: https://commons.wikimedia.org/wiki/File:Preliminary_discussions_regarding_Lua_bot_framework.webm

Licence: CC BY-SA 4.0, https://creativecommons.org/licenses/by-sa/4.0/ . The sample appears as cropped, resized on-screen excerpts, with its original audio omitted. The practice transcript contains deliberately seeded wording changes. No endorsement by the source creator or sample participants is implied.

Use the URL of the standalone application repository when sharing this tour. Do not link to a private research project or unrelated application repository.

## Media rights and sharing scope

- **Narration:** this cut uses audio generated under the user-confirmed ElevenLabs Free, noncommercial scope. Do not use it in paid advertising, commercial promotion or another commercial context. Publishing requires `elevenlabs.io` or `11.ai` in the title. Upgrading later does not retroactively license this audio commercially; replace the narration with appropriately licensed audio for a commercial edition. See the [official ElevenLabs publishing guidance](https://help.elevenlabs.io/hc/en-us/articles/13313564601361-Can-I-publish-the-content-I-generate-on-the-platform), checked 9 September 2026.
- **Public sample:** Jim Carter's source and adaptations of that footage retain [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Keep the source, creator, licence and modification notice with shared copies. The noncommercial limitation on the separate ElevenLabs narration does not relicense or restrict the original CC BY-SA source material.
- **Mixed media:** do not label this entire folder or combined video as MIT, unrestricted commercial media, or exclusively yours. Keep the component-specific notices. ShareAlike obligations may affect adaptations of the sample; this production handoff is not a blanket legal clearance for every subsequent remix or distribution context.
- **Editable composition:** original composition code is MIT-licensed, with the licence included in `editable/LICENSE`. The package is private only to prevent accidental npm publication. This does not relicense media or dependencies. Remotion has its own [licensing requirements](https://github.com/remotion-dev/remotion/blob/main/LICENSE.md).

## Accurate product claims

- The current demonstrated workflow uses two local decoding passes of the same model. These are candidate transcripts, not independent witnesses; both can make the same mistake.
- Confidence and disagreement flags are review aids, not calibrated probabilities that a word is correct. Unflagged passages can still be wrong.
- The correction shown was saved as **pending**, not certified as verified. The `[practice-error]` example is deliberately seeded.
- Word, NVivo-style DOCX, spreadsheet and subtitle exports were generated from the public demo. This video is not a claim of end-to-end import certification in every version of NVivo, Word or other analysis software.
- Current documented supported installation is Apple Silicon macOS. Windows, Linux and Intel Mac paths are experimental and have not been release-validated. The narration does not claim all-platform support.
- Local processing concerns the app's handling of recordings and transcripts. Initial setup may download model weights and dependencies. User-selected cloud-synced folders, operating-system backups, browser extensions or subsequent sharing are outside that guarantee.
- ElevenLabs was used to produce this public promotional narration only. It is not part of the product's speech-recognition workflow. No research recording or interview transcript was supplied to ElevenLabs.

## Before posting

1. Watch the MP4 once at normal speed and approve the voice and pace.
2. Keep the title attribution and source-credit paragraphs above with the post.
3. Use only this public-demo media folder, not the private app data folder or interview directories.
4. Keep application source and public demo assets separate from all private research data. Preserve the media notices when sharing this handoff.
5. Do not attach the SRT as an additional visible subtitle track unless desired: the delivered MP4 already has English captions burned in.
